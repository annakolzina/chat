<?php

use yii\helpers\Html;
use yii\grid\GridView;
use app\models\Messages;
use app\models\People;

/* @var $this yii\web\View */
/* @var $searchModel app\models\MessagesSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Сообщения';
?>
<div class="messages-index">

    <h1><?= Html::encode($this->title) ?></h1>

 
    <?php
        $new_mes = new Messages();
        if ($new_mes->load(Yii::$app->request->post())) {
            $new_mes->time_begin = date("Y-m-d H:i:s");
            $new_mes->id_people = Yii::$app->user->getId();
            $new_mes->save();
            $new_mes->text = "";
        }
       echo $this->render('create',
                ['model' => $new_mes]);
        
   ?>

    <?= GridView::widget([
        'rowOptions' => function ($model) {
        $people = People::find()->where(['id' => $model->id_people])->one();
        if($people->role==1){
            $class = 'success';
        }else{
            $class = 'warning'; 
        }
         return ['class' => $class];
     },
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn',
                'header' => '№'],
            [
                'attribute' => 'id_people',
                'value' => function($model){
                     return $model->people->username;
                }
                ],
            'time_begin:datetime',
            'text:ntext',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
    
    


</div>
