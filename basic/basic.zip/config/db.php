<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=127.0.0.1;dbname=chat',
    'username' => 'root',
    'password' => 'root',
    'charset' => 'utf8',
];
